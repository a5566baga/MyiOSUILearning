//
//  AppDelegate.h
//  LabelDemo
//
//  Created by 张永刚 on 16/7/18.
//  Copyright © 2016年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

